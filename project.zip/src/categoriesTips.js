export const categoriesTips = [
  { id: 1, name: 'Basics', icon: 'basic.svg', path: 'basic' },
  { id: 2, name: 'Head', icon: 'head.svg', path: 'head' },
  { id: 3, name: 'Hands', icon: 'hands.svg', path: 'hands' },
  { id: 4, name: 'Legs', icon: 'legs.svg', path: 'legs' },
  { id: 5, name: 'Body', icon: 'body.svg', path: 'body' },
  { id: 6, name: 'Composition', icon: 'composition.svg', path: 'composition' },
  { id: 7, name: 'Equipment', icon: 'equipment.svg', path: 'equipment' },
];
