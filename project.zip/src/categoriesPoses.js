export const categoriesPoses = [
  { id: 1, name: 'Kids', icon: 'children.svg', path: 'children' },
  { id: 2, name: 'Womens', icon: 'women.svg', path: 'women' },
  { id: 3, name: 'Mens', icon: 'men.svg', path: 'men' },
  { id: 4, name: 'Couples', icon: 'couples.svg', path: 'couples' },
  { id: 5, name: 'Groups', icon: 'groups.svg', path: 'groups' },
  { id: 6, name: 'Weddings', icon: 'wedding.svg', path: 'wedding' },
  { id: 7, name: 'Glamours', icon: 'glamour.svg', path: 'glamour' },
];
